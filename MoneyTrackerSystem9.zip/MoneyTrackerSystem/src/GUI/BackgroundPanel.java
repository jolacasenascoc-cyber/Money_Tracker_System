package GUI;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class BackgroundPanel extends RoundedPanel {

    private Image backgroundImage;

    public BackgroundPanel() {
    super(0);
        java.net.URL url = getClass().getResource("/images/background14.jpg");
        if (url != null) {
            backgroundImage = new ImageIcon(url).getImage();
        } else {
            System.err.println("Background image not found: /images/background14.jpg");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}