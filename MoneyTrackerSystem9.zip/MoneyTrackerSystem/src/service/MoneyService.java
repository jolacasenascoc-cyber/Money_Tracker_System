package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.MoneyTracker;

public class MoneyService {

    // =========================
    // DATABASE CONNECTION
    // =========================

    private static final String URL =
            "jdbc:mysql://localhost:3306/money_tracker?useSSL=false&serverTimezone=UTC";

    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // =========================
    // REGISTER USER
    // =========================

    public static boolean registerUser(MoneyTracker user) {
   // id_number is AUTO_INCREMENT, so the database creates it
    String sql = "INSERT INTO users "
            + "(name, lname, password, income, security_answer) "
            + "VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(
                 sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

        stmt.setString(1, user.getName());
        stmt.setString(2, user.getLname());
        stmt.setString(3, user.getPassword());
        stmt.setDouble(4, user.getIncome());
        stmt.setString(5, user.getSecurityAnswer());

        stmt.executeUpdate();

        // get the ID the database just created
        try (ResultSet keys = stmt.getGeneratedKeys()) {
            if (keys.next()) {
                addIncomeHistory(keys.getString(1), user.getIncome());
            }
        }

        return true;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}    
    public static boolean userExists(String name, String lname) {

    String sql = "SELECT 1 FROM users WHERE name = ? AND lname = ?";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, name);
        stmt.setString(2, lname);

        return stmt.executeQuery().next();

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
    
    
    // =========================
    // PASSWORD VALIDATION
    // =========================

    public static String validatePassword(String password) {
       if (password.length() < 8) {
        return "Password must be at least 8 characters.";
        }
        if (!password.matches(".*[^A-Za-z0-9\\s].*")) {
            return "Password must contain at least one special character (e.g. ! @ # $ %).";
        }
        return null; // null = valid
    }

    // =========================
    // VERIFY SECURITY ANSWER
    // =========================

    public static boolean verifySecurityAnswer(String idNumber, String securityAnswer) {

        String sql = "SELECT 1 FROM users WHERE id_number = ? AND security_answer = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setString(2, securityAnswer);

            return stmt.executeQuery().next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // UPDATE PASSWORD
    // =========================

    public static boolean updatePassword(String idNumber, String newPassword) {

        String sql = "UPDATE users SET password = ? WHERE id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, newPassword);
            stmt.setString(2, idNumber);

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    // =========================
    // LOGIN USER
    // =========================

    public static MoneyTracker loginUser(
        String name,
        String lname,
        String password) {

    String sql = "SELECT * FROM users "
            + "WHERE name = ? AND lname = ? AND password = ?";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, name);
        stmt.setString(2, lname);
        stmt.setString(3, password);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {

            return new MoneyTracker(
                    rs.getString("id_number"),
                    rs.getString("name"),
                    rs.getString("lname"),
                    rs.getString("password"),
                    rs.getDouble("income"),
                    rs.getString("Security_answer")
            );
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return null;
}

    // =========================
    // GET EXPENSES
    // =========================

    public static Object[][] getExpenses(String idNumber)
            throws Exception {

        String sql = "SELECT expense_id, category, description, amount, expense_date "
                + "FROM expenses "
                + "WHERE id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);

            ResultSet rs = stmt.executeQuery();

            ArrayList<Object[]> list = new ArrayList<>();

            while (rs.next()) {

                Object[] row = {
                    rs.getInt("expense_id"),
                    rs.getString("category"),
                    rs.getString("description"),
                    rs.getDouble("amount"),
                    rs.getDate("expense_date")
                };

                list.add(row);
            }

            return list.toArray(new Object[0][]);
        }
    }

    // =========================
    // ADD EXPENSE
    // =========================

    public static boolean addExpense(
            String idNumber,
            String category,
            String description,
            double amount) {

        String getIdSql =
                "SELECT COALESCE(MAX(expense_id), 0) + 1 AS next_id "
                + "FROM expenses WHERE id_number = ?";

        String insertSql =
                "INSERT INTO expenses "
                + "(expense_id, id_number, category, description, amount, expense_date) "
                + "VALUES (?, ?, ?, ?, ?, CURRENT_DATE)";

        try (Connection conn = getConnection();
             PreparedStatement getIdStmt =
                     conn.prepareStatement(getIdSql)) {

            getIdStmt.setString(1, idNumber);

            ResultSet rs = getIdStmt.executeQuery();

            int nextId = 1;

            if (rs.next()) {
                nextId = rs.getInt("next_id");
            }

            try (PreparedStatement insertStmt =
                         conn.prepareStatement(insertSql)) {

                insertStmt.setInt(1, nextId);
                insertStmt.setString(2, idNumber);
                insertStmt.setString(3, category);
                insertStmt.setString(4, description);
                insertStmt.setDouble(5, amount);

                insertStmt.executeUpdate();
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // UPDATE EXPENSE
    // =========================

    public static boolean updateExpense(
            String idNumber,
            int expenseId,
            String category,
            String description,
            double amount) {

        String sql = "UPDATE expenses SET "
                + "category = ?, "
                + "description = ?, "
                + "amount = ? "
                + "WHERE expense_id = ? AND id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, category);
            stmt.setString(2, description);
            stmt.setDouble(3, amount);
            stmt.setInt(4, expenseId);
            stmt.setString(5, idNumber);

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // DELETE EXPENSE
    // =========================

    public static boolean deleteExpense(
            String idNumber,
            int expenseId) {

        String sql = "DELETE FROM expenses "
                + "WHERE expense_id = ? AND id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, expenseId);
            stmt.setString(2, idNumber);

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // TOTAL MONEY SPENT
    // =========================

    public static double getTotalSpent(String idNumber)
            throws Exception {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS total "
                + "FROM expenses "
                + "WHERE id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }

        return 0;
    }

    // =========================
    // MONEY AVAILABLE
    // =========================

    public static double getMoneyAvailable(
            String idNumber,
            double income) throws Exception {

        double spent = getTotalSpent(idNumber);

        return income - spent;
    }

    // =========================
    // MONEY SAVED
    // =========================

    public static double getMoneySaved(
            String idNumber,
            double income) throws Exception {

        double spent = getTotalSpent(idNumber);

        return income - spent;
    }
    
    // =========================
    // FORGOT PASSWORD
    // =========================
    
    public static String getForgottenPassword(
            String name,
            String lname,
            String securityAnswer) {

        String sql = "SELECT password FROM users "
                + "WHERE name = ? AND lname = ? AND security_answer = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, lname);
            stmt.setString(3, securityAnswer);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("password");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    
    // =========================
    // UPDATE INCOME
    // =========================
    
    public static boolean updateIncome(String idNumber, double newIncome) {

        String sql = "UPDATE users SET income = ? WHERE id_number = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, newIncome);
            stmt.setString(2, idNumber);

            stmt.executeUpdate();
            
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
}
    
    // =========================
    // INCOME HISTORY
    // =========================
    
    public static boolean addIncomeHistory(
            String idNumber,
            double amount) {

        String sql = "INSERT INTO income_history "
                + "(id_number, amount, date_added) "
                + "VALUES (?, ?, CURRENT_DATE)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setDouble(2, amount);

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static Object[][] getIncomeHistory(String idNumber)
            throws Exception {

        String sql = "SELECT amount, date_added "
                + "FROM income_history "
                + "WHERE id_number = ? "
                + "ORDER BY date_added DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);

            ResultSet rs = stmt.executeQuery();

            ArrayList<Object[]> list = new ArrayList<>();

            while (rs.next()) {

                Object[] row = {
                    rs.getDouble("amount"),
                    rs.getDate("date_added")
                };

                list.add(row);
            }

            return list.toArray(new Object[0][]);
        }
    }
    
    public static double getCategoryTotal(
            String idNumber,
            String category) throws Exception {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS total "
                + "FROM expenses "
                + "WHERE id_number = ? AND category = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setString(2, category);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }

        return 0;
    }
 
    
        // =========================
    // MONTHLY TOTALS (they start from zero every new month)
    // =========================

    // Money added to the allowance during the CURRENT month
    public static double getMonthlyAllowance(String idNumber)
            throws Exception {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS total "
                + "FROM income_history "
                + "WHERE id_number = ? "
                + "AND YEAR(date_added) = YEAR(CURDATE()) "
                + "AND MONTH(date_added) = MONTH(CURDATE())";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }

        return 0;
    }

    // Money spent during the CURRENT month
    public static double getMonthlySpent(String idNumber)
            throws Exception {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS total "
                + "FROM expenses "
                + "WHERE id_number = ? "
                + "AND YEAR(expense_date) = YEAR(CURDATE()) "
                + "AND MONTH(expense_date) = MONTH(CURDATE())";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }

        return 0;
    }

    // Necessities / Wants / Food spent during the CURRENT month
    public static double getMonthlyCategoryTotal(
            String idNumber,
            String category) throws Exception {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS total "
                + "FROM expenses "
                + "WHERE id_number = ? AND category = ? "
                + "AND YEAR(expense_date) = YEAR(CURDATE()) "
                + "AND MONTH(expense_date) = MONTH(CURDATE())";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setString(2, category);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }

        return 0;
    }

    // =========================
    // MONEY SAVED (does NOT restart every month)
    // = all money ever added - all money ever spent
    // =========================

    public static double getTotalSaved(String idNumber)
            throws Exception {

        String sql = "SELECT "
                + "(SELECT COALESCE(SUM(amount), 0) FROM income_history "
                + "  WHERE id_number = ?) "
                + "- (SELECT COALESCE(SUM(amount), 0) FROM expenses "
                + "  WHERE id_number = ?) AS saved";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setString(2, idNumber);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("saved");
            }
        }

        return 0;
    }

    // =========================
    // MONTHLY HISTORY (one row for EVERY month, newest first)
    // Each row = { "October 2026", allowance, save, expenses }
    // Months with no activity are shown with zeros.
    // =========================

    public static Object[][] getMonthlyHistory(String idNumber)
            throws Exception {

        String sql = "SELECT ym, SUM(allowance) AS allowance, SUM(spent) AS spent "
                + "FROM ( "
                + "  SELECT DATE_FORMAT(date_added, '%Y-%m') AS ym, "
                + "         amount AS allowance, 0 AS spent "
                + "  FROM income_history WHERE id_number = ? "
                + "  UNION ALL "
                + "  SELECT DATE_FORMAT(expense_date, '%Y-%m') AS ym, "
                + "         0 AS allowance, amount AS spent "
                + "  FROM expenses "
                + "  WHERE id_number = ? AND expense_date IS NOT NULL "
                + ") AS months "
                + "GROUP BY ym "
                + "ORDER BY ym";

        java.time.format.DateTimeFormatter format =
                java.time.format.DateTimeFormatter.ofPattern(
                        "MMMM yyyy", java.util.Locale.ENGLISH);

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idNumber);
            stmt.setString(2, idNumber);

            ResultSet rs = stmt.executeQuery();

            // month -> { allowance, spent }
            java.util.TreeMap<java.time.YearMonth, double[]> months =
                    new java.util.TreeMap<>();

            while (rs.next()) {
                months.put(
                        java.time.YearMonth.parse(rs.getString("ym")),
                        new double[]{
                            rs.getDouble("allowance"),
                            rs.getDouble("spent")
                        });
            }

            if (months.isEmpty()) {
                return new Object[0][];
            }

            // the current month, taken from the database clock
            java.time.YearMonth current;

            try (java.sql.Statement st = conn.createStatement();
                 ResultSet r = st.executeQuery(
                         "SELECT DATE_FORMAT(CURDATE(), '%Y-%m')")) {

                r.next();
                current = java.time.YearMonth.parse(r.getString(1));
            }

            java.time.YearMonth first = months.firstKey();
            java.time.YearMonth last = months.lastKey().isAfter(current)
                    ? months.lastKey() : current;

            ArrayList<Object[]> list = new ArrayList<>();

            // newest month first, down to the first month with activity
            for (java.time.YearMonth ym = last;
                    !ym.isBefore(first);
                    ym = ym.minusMonths(1)) {

                double[] v = months.getOrDefault(ym, new double[]{0, 0});

                Object[] row = {
                    ym.format(format),
                    v[0],            // total month allowance
                    v[0] - v[1],     // total month save
                    v[1]             // total month expenses
                };

                list.add(row);
            }

            return list.toArray(new Object[0][]);
        }
    }
}
