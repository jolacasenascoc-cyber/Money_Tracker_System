package model;

public class MoneyTracker {

    private String idNumber;
    private String name;
    private String lname;
    private String password;
//    private String occupation;
    private double income;
    private String securityAnswer;

    // Constructor
    public MoneyTracker(
            String idNumber,
            String name,
            String lname,
            String password,
//            String occupation,
            double income,
            String securityAnswer) {

        this.idNumber = idNumber;
        this.name = name;
        this.lname = lname;
        this.password = password;
//        this.occupation = occupation;
        this.income = income;
        this.securityAnswer = securityAnswer;
    }

    // Getters
    public String getIdNumber() {
        return idNumber;
    }

    public String getName() {
        return name;
    }
    
    public String getLname() {
        return lname;
    }

    public String getPassword() {
        return password;
    }

/*    public String getOccupation() {
        return occupation;
    }
*/

    public double getIncome() {
        return income;
    }
        
    public String getSecurityAnswer() {
        return securityAnswer;
    }
    

    // Setters
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

/*    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }
*/

    public void setIncome(double income) {
        this.income = income;
    }
    
    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }
}